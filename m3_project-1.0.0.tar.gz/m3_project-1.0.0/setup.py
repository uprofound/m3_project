from setuptools import find_packages, setup

setup(
    name='m3_project',
    version='1.0.0',
    packages=find_packages(),
    scripts=['manage.py']
)
